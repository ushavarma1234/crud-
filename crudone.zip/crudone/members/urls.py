from django.urls import path
from . import views

urlpatterns = [
    path('api/members/', views.members, name='get_members'), 
    path('api/login/', views.custom_login, name='login'),
    path('api/members/<int:id>/', views.delete_member, name='delete_member'),
    path('api/update/<int:id>/', views.update, name='update'),
    path('api/otp/',views.verify_otp,name='verify_otp'),
  
]


