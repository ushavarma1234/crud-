from django.db import models


class Name(models.Model):
    firstname = models.CharField(max_length=255)
    lastname = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.firstname} {self.lastname}"

class Contact(models.Model):
    member = models.ForeignKey(Name, on_delete=models.CASCADE)
    email = models.EmailField(max_length=255)
    password = models.CharField(max_length=255)  # Add password field
    phone_number = models.CharField(max_length=20)
    otp = models.CharField(max_length=6, default='000000')


    def __str__(self):
        return self.email  # Or whatever representation you prefer



