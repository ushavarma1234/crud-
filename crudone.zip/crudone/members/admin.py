from django.contrib import admin
from .models import Name, Contact

@admin.register(Name)
class NameAdmin(admin.ModelAdmin):
    list_display = ('firstname', 'lastname')  # Customize the display in the admin list

@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('member', 'email', 'phone_number', 'otp')  # Customize the display in the admin list


