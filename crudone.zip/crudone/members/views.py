from audioop import reverse
from enum import member
from multiprocessing import AuthenticationError
from pyexpat.errors import messages
from types import MemberDescriptorType
from django.contrib.auth import authenticate, login
from django.http import HttpResponseNotFound, HttpResponseRedirect, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from .models import Name, Contact
    
from django.http import JsonResponse
from .models import Contact

from members.apps import MembersConfig
from .models import Name, Contact
import json
from django.core.mail import send_mail
import random



import random
from django.core.mail import send_mail
from django.conf import settings

@csrf_exempt
def members(request):
    if request.method == 'GET':
        members = Contact.objects.all()
        data = [{'id': member.id, 'firstname': member.member.firstname, 'lastname': member.member.lastname,
                 'email': member.email, 'phone': member.phone_number} for member in members]
        return JsonResponse(data, safe=False)
    
    elif request.method == 'POST':
        try:
            body_data = json.loads(request.body.decode('utf-8'))
            firstname = body_data.get('firstname')
            lastname = body_data.get('lastname')
            email = body_data.get('email')
            phone = body_data.get('phone')
            password = body_data.get('password')
            confirm_password = body_data.get('confirm_password')

            if not all([firstname, lastname, email, phone, password, confirm_password]):
                return JsonResponse({'error': 'All fields are required'}, status=400)

            if password != confirm_password:
                return JsonResponse({'error': 'Password and confirm password do not match'}, status=400)

            # Generate OTP
            otp = ''.join(random.choices('0123456789', k=6))  # Generate a 6-digit OTP
            # Save the OTP in the database (you'll need a field to store OTP in your Contact model)
            new_member = Name.objects.create(firstname=firstname, lastname=lastname)
            new_contact = Contact.objects.create(member=new_member, email=email, phone_number=phone, otp=otp)
            new_contact.save()

            # Send OTP to the registered email
            subject = 'Your OTP for registration'
            message = f'Your OTP is: {otp}'
            from_email = settings.EMAIL_HOST_USER
            recipient_list = [email]
            send_mail(subject, message, from_email, recipient_list)


            return JsonResponse({'message': 'Member added successfully. OTP sent to registered email.'}, status=201)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)

    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)




@csrf_exempt
def custom_login(request):
 
    if request.method == 'POST':
  
        # AuthenticationForm_can_also_be_used__
  
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username = username, password = password)
        if user is not None:
            form = login(request, user)
            messages.success(request, f' welcome {username} !!')
            return redirect('index')
        else:
            messages.info(request, f'account done not exit plz sign in')
    form = AuthenticationError()
    return render(request, 'user/login.html', {'form':form, 'title':'log in'})






def delete_member(request, id):
    try:
        member = Contact.objects.get(id=id)
        member.delete()
        return JsonResponse({'message': f'Member with ID {id} deleted successfully.'}, status=200)
    except Contact.DoesNotExist:
        return HttpResponseNotFound('Member not found')

from .models import Name, Contact  # Import the Member model from your models file



@csrf_exempt
def update(request, id):
    # Get the contact object or return 404 if not found
    contact = get_object_or_404(Contact, id=id)
    member = contact.member
    
    if request.method == 'PUT':
        # Update member details based on the PUT request data
        # For example:
        member.firstname = request.POST.get('firstname', member.firstname)
        member.lastname = request.POST.get('lastname', member.lastname)
        # Update other fields similarly
        
        # Save the updated member object
        member.save()
        
        # Return a JSON response indicating success
        return JsonResponse({'message': 'Member updated successfully'})
    else:
        # Handle other HTTP methods if necessary
        return JsonResponse({'error': 'Unsupported method'}, status=405)



@csrf_exempt
def verify_otp(request):
    if request.method == 'POST':
        try:
            body_data = json.loads(request.body.decode('utf-8'))
            otp = body_data.get('otp')
            
            # Debugging statement
            print("Received OTP:", otp)
            
            # Perform OTP validation logic here (e.g., check against a stored OTP)
            # For demonstration purposes, assume the correct OTP is retrieved from the database
            # Replace the below line with your actual OTP validation logic
            correct_otp = '123456'  # Example correct OTP
            
            # Debugging statement
            print("Correct OTP:", correct_otp)
            
            if otp == correct_otp:
                return JsonResponse({'message': 'OTP verified successfully'}, status=200)
            else:
                return JsonResponse({'error': 'Invalid OTP'}, status=400)
        except json.JSONDecodeError:
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)
    else:
        return JsonResponse({'error': 'Method not allowed'}, status=405)

